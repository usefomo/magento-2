<?php

namespace SweetTooth\Webhook\Test\Unit\Controller\Adminhtml\System\Webhook;

/**
 * TODO: Write tests
 *
 * WHAT!? NO TESTS!? BLASPHEMY!!
 * 
 * Yo, chill. We're all for writing tests but while this module is in
 * beta (as is Magento 2 itself) TDD can be counter productive while many
 * are learning the Magento 2 framework itself. These tests will come. All in
 * good time :)
 */
class ValidateTest extends \PHPUnit_Framework_TestCase
{
}
